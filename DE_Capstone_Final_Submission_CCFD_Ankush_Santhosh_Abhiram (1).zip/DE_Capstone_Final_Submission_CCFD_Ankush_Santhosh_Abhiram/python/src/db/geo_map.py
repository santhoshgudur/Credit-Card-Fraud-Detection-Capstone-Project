import sys

sys.path.insert(0, '/home/hadoop/python/src/db')
from math import atan2, cos, radians, sin, sqrt

import pandas as pd


def get_lat(zipcode):
    df = pd.read_csv('uszipsv.csv', header=None, names=['zipcode', 'latitude', 'longitude', 'city', 'state'])
    try:
        lat = df.loc[df['zipcode'] == 10949, 'latitude'].values[0]
    except IndexError:
        print(f"No latitude found for zipcode {zipcode}")
        lat = None
    return lat

def get_long(zipcode):
    df = pd.read_csv('uszipsv.csv', header=None, names=['zipcode', 'latitude', 'longitude', 'city', 'state'])
    try:
        longi = df.loc[df['zipcode'] == 10949, 'longitude'].values[0]
        print ("Inside function",longi)
    except IndexError:
        print(f"No longitude found for zipcode {zipcode}")
        longi = None
    return longi

def distance(lat1, long1, lat2, long2):
    R = 6373.0 # approximate radius of earth in km

    lat1 = radians(lat1)
    long1 = radians(long1)
    lat2 = radians(lat2)
    long2 = radians(long2)

    dlon = long2 - long1
    dlat = lat2 - lat1

    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))

    distance = R * c

    return distance
