import happybase
def get_data(key, table):
        try:
            # Connect to HBase
            connection = happybase.Connection('ec2-35-175-65-104.compute-1.amazonaws.com', port=9090)

            # Retrieve data from the table
            table = connection.table(table)
            row = table.row(key)

            return row

        except Exception as e:
            print(f"Error: {e}")

def write_data(key, row, tablename):
    try:
        connection = happybase.Connection('ec2-35-175-65-104.compute-1.amazonaws.com', port=9090)
        table = connection.table(tablename)
        table.put(key, row)
    except Exception as e:
        print(f"Error writing data to HBase table: {e}")
