import sys
sys.path.insert(0, '/home/hadoop/python/src/db')
sys.path.insert(0, '/home/hadoop/python/src/rules')
from dao import *
from geo_map import *
from datetime import datetime
import uuid
lookup_table = 'look_up_table'
master_table = 'card_transactions'
speed_threshold = 0.25  # km/sec - Average speed of flight 900 km/hr


def check_ucl(card_id, amount):
    try:
        card_row = get_data(key=str(card_id), table=lookup_table)
        
        if card_row is not None and b'Rule_params:UCL' in card_row:
            card_ucl = card_row[b'Rule_params:UCL'].decode("utf-8")
        else:
            return True # If the card id is not present in look_up_table table then it means it is for new customer and so passing the 1st rule for check ucl

        if amount < float(card_ucl):
            return True
        else:
            return False
    except Exception as e:
        raise Exception(e)


def check_credit_score(card_id):

    try:

        card_row = get_data(key=str(card_id), table=lookup_table)
        if card_row is not None and b'Rule_params:score' in card_row:
            card_score = (card_row[b'Rule_params:score']).decode("utf-8")
        else:
            return True # If the card id is not present in look_up_table table then it means it is for new customer and so passing the 2nd rule for check credit score

        if int(card_score) > 200:
            return True
        else:
            return False
    except Exception as e:
        raise Exception(e)


def check_speed(card_id, postcode, transaction_dt):

    try:
        card_row = get_data(key=str(card_id), table=lookup_table)
        
        if card_row is not None and b'Rule_params:postcode' in card_row and b'card_details:transaction_dt' in card_row:
            last_postcode = (card_row[b'Rule_params:postcode']).decode("utf-8")
            last_transaction_dt = (card_row[b'card_details:transaction_dt']).decode("utf-8")
        else:
            return True

        current_lat = get_lat(str(postcode))
        current_lon = get_long(str(postcode))
        previous_lat = get_lat(last_postcode)
        previous_lon = get_long(last_postcode)

        dist = distance(lat1=current_lat, long1=current_lon, lat2=previous_lat, long2=previous_lon)

        speed = get_speed(dist, transaction_dt, last_transaction_dt)

        if speed < speed_threshold:
            return True
        else:
            return False

    except Exception as e:
        raise Exception(e)


def get_speed(dist, transaction_dt1, transaction_dt2):

    try:
        transaction_dt1 = datetime.strptime(transaction_dt1, '%d-%m-%Y %H:%M:%S')
        transaction_dt2 = datetime.strptime(transaction_dt2, '%d-%m-%Y %H:%M:%S')

        elapsed_time = transaction_dt1 - transaction_dt2
        elapsed_time = elapsed_time.total_seconds()
        
        return dist / elapsed_time
    except:
        return 299792.458


def verify_all_rules(card_id, member_id, amount, pos_id, postcode, transaction_dt):

    if card_id is None:
        return

    rule1 = check_ucl(card_id, amount)
    rule2 = check_credit_score(card_id)
    rule3 = check_speed(card_id, postcode, transaction_dt)
    
    if all([rule1, rule2, rule3]):
        status = 'GENUINE'
        write_data(key=str(card_id),
                       row={'Rule_params:postcode': str(postcode), 'card_details:transaction_dt': str(transaction_dt)},
                       tablename=lookup_table)
    else:
        status = 'FRAUD'
        new_id = str(uuid.uuid4()).replace('-', '')
        write_data(key=new_id,
               row={'TD:card_id': str(card_id), 'TD:member_id': str(member_id),
                    'TD:amount': str(amount), 'TD:pos_id': str(pos_id),
                    'TD:postcode': str(postcode), 'TD:status': str(status),
                    'TD:transaction_dt': str(transaction_dt)},
               tablename=master_table)
    
    return status
