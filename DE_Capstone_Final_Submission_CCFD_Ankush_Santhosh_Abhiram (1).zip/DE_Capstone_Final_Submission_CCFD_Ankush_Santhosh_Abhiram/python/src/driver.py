import os
import sys
import happybase
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

sys.path.insert(0, '/home/hadoop/python/src/db')
sys.path.insert(0, '/home/hadoop/python/src/rules')

#initialising Spark session
spark = SparkSession  \
    .builder  \
    .appName("CreditCardFraud")  \
    .getOrCreate()
spark.sparkContext.setLogLevel('ERROR')

spark.sparkContext.addFile('db/dao.py')
spark.sparkContext.addFile('db/geo_map.py')
spark.sparkContext.addFile('rules/rules.py')
spark.sparkContext.addFile('db/uszipsv.csv')

import rules

# Reading input from Kafka
transaction_data = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "18.211.252.152:9092") \
    .option("startingOffsets","earliest") \
    .option("failOnDataLoss", "false") \
    .option("subscribe", "transactions-topic-verified") \
    .load()

# Defining schema for transaction
transactionDataSchema = StructType() \
    .add("card_id", LongType()) \
    .add("member_id", LongType()) \
    .add("amount", DoubleType()) \
    .add("pos_id", LongType()) \
    .add("postcode", IntegerType()) \
    .add("transaction_dt", StringType())

# Casting raw data as string and aliasing
transaction_data = transaction_data.selectExpr("cast(value as string)")
transact_data_raw = transaction_data.select(from_json(col="value", schema=transactionDataSchema).alias("credit_data")).select(
    "credit_data.*")

verify_all_rules = udf(rules.verify_all_rules, StringType())

Transaction_Data = transact_data_raw \
    .withColumn('status', verify_all_rules(transact_data_raw['card_id'],
                                           transact_data_raw['member_id'],
                                           transact_data_raw['amount'],
                                           transact_data_raw['pos_id'],
                                           transact_data_raw['postcode'],
                                           transact_data_raw['transaction_dt']))
# Write output to console
output_data = Transaction_Data \
    .select("card_id", "member_id", "amount", "pos_id", "postcode", "transaction_dt", "status") \
    .writeStream \
    .outputMode("append") \
    .format("console") \
    .option("truncate", "false") \
    .option("numRows", 35) \
    .start()

#Spark to await termination
output_data.awaitTermination()
