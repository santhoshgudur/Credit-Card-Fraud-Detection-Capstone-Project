# Streaming Application to read from Kafka
# This should be the driver file for your project